__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/a2d757050a4c61ac.js",
  "static/chunks/turbopack-3addfa5ff4b4cc71.js"
])
