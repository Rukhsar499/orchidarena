var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/submitbooking/route.js")
R.c("server/chunks/[root-of-the-server]__22f4fe83._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(19486)
R.m(62204)
module.exports=R.m(62204).exports
