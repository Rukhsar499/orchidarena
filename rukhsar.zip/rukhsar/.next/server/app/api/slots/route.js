var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/slots/route.js")
R.c("server/chunks/[root-of-the-server]__697ee658._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(58490)
R.m(88605)
module.exports=R.m(88605).exports
