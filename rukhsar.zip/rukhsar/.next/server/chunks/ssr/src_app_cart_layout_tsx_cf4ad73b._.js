module.exports=[32523,a=>{"use strict";a.s(["default",()=>d,"metadata",()=>c]);var b=a.i(7997);let c={title:"Cart - PSM - Turf",description:"Cart for booking turf"};function d({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}}];

//# sourceMappingURL=src_app_cart_layout_tsx_cf4ad73b._.js.map