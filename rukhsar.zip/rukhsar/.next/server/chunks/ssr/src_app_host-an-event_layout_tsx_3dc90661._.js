module.exports=[42952,a=>{"use strict";a.s(["default",()=>d,"metadata",()=>c]);var b=a.i(7997);let c={title:"Host An Event - Narayana",description:"Sports Narayana Website"};function d({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}}];

//# sourceMappingURL=src_app_host-an-event_layout_tsx_3dc90661._.js.map