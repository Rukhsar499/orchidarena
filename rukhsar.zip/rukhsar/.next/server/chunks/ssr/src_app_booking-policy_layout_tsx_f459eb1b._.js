module.exports=[4141,a=>{"use strict";a.s(["default",()=>d,"metadata",()=>c]);var b=a.i(7997);let c={title:"Booking Policy",description:"Booking Policy of PSM Trurf"};function d({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}}];

//# sourceMappingURL=src_app_booking-policy_layout_tsx_f459eb1b._.js.map