module.exports=[97813,a=>{"use strict";a.s(["default",()=>d,"metadata",()=>c]);var b=a.i(7997);let c={title:"Privacy Policy",description:"Privacy Policy - PSM Turf"};function d({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}}];

//# sourceMappingURL=src_app_privacy-policy_layout_tsx_1b723209._.js.map