globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/a2d757050a4c61ac.js",
      "static/chunks/turbopack-3addfa5ff4b4cc71.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/a2d757050a4c61ac.js",
      "static/chunks/turbopack-abf8d71c35b666de.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/3eba6931cad880e3.js",
    "static/chunks/47f477e3d2ef265b.js",
    "static/chunks/150316a471952cee.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-e0003e8d3992625e.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];